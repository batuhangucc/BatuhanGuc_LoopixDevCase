using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    /// <summary>
    /// Oyunu başlatır (ana oyun sahnesine geçiş yapar).
    /// </summary>
    public void StartGame()
    {
        
        SceneManager.LoadScene("MainScene");
    }

    /// <summary>
    /// Oyunu kapatır.
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("Oyun kapatılıyor...");
        Application.Quit();
    }
}