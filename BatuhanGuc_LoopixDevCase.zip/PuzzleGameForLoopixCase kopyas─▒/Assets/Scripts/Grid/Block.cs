using System.Collections;
using UnityEngine;

/// <summary>
/// Sahnedeki her blok nesnesini temsil eder.
/// - Görsellik atama
/// - Hücreye düşme animasyonu
/// - Eşleşme sonrası yok olma ve efekt
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class Block : MonoBehaviour
{
    [Header("Blok Verisi")]
    public BlockType blockType;

    [Header("Efekt Prefab")]
    [SerializeField] private GameObject explosionEffectPrefab;

    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        ApplyVisuals();
    }

    /// <summary>
    /// Blok görünümünü BlockType verisine göre uygular.
    /// </summary>
    public void ApplyVisuals()
    {
        if (blockType == null) return;

        spriteRenderer.sprite = blockType.sprite;
        spriteRenderer.color = blockType.color;

        if (blockType.material != null)
        {
            spriteRenderer.material = blockType.material;
        }
    }

    /// <summary>
    /// Blok’u yukarıdan hedef hücreye animasyonlu şekilde düşürür ve yerleştirir.
    /// </summary>
    public IEnumerator FallAndPlace(GridCell targetCell, float duration = 0.3f)
    {
        Vector3 start = transform.position;
        Vector3 end = targetCell.transform.position;

        float time = 0f;
        while (time < duration)
        {
            transform.position = Vector3.Lerp(start, end, time / duration);
            time += Time.deltaTime;
            yield return null;
        }

        transform.position = end;
        targetCell.currentBlock = this;

        // Blok yerleştirildikten kısa süre sonra eşleşme kontrolü yapılır
        yield return new WaitForSeconds(0.1f);
        GridManager.Instance.CheckForMatches();
    }

    /// <summary>
    /// Eşleşen blok için animasyon oynatır ve ardından sahneden kaldırır.
    /// </summary>
    public IEnumerator PlayMatchSequence()
    {
        Animator anim = GetComponent<Animator>();

        if (anim != null)
        {
            anim.SetTrigger("Play");
            yield return new WaitForSeconds(0.4f); // Animasyon süresi
        }

        ExplodeEffect();               // Patlama efekti
        Destroy(gameObject);           // Objeyi sahneden kaldır
    }

    /// <summary>
    /// Patlama efektini çalıştırır ve blok rengini uygular.
    /// </summary>
    private void ExplodeEffect()
    {
        if (explosionEffectPrefab == null) return;

        GameObject fx = Instantiate(explosionEffectPrefab, transform.position, Quaternion.identity);

        if (fx.TryGetComponent(out ParticleSystemRenderer psr))
        {
            Material matInstance = new Material(psr.material);

            Color glowColor = blockType.color * 2f;
            glowColor.a = 1f;

            matInstance.SetColor("_BaseColor", glowColor);
            matInstance.SetColor("_EmissionColor", glowColor);

            psr.material = matInstance;
        }
    }
}