using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class GridCell : MonoBehaviour, IDropHandler
{
    public Vector2Int gridPosition;              // Grid içindeki konumu (x, y)
    public Block currentBlock;                   // Hücredeki mevcut blok (varsa)

    /// <summary>
    /// Sürüklenen blok bu hücreye bırakıldığında çağrılır.
    /// </summary>
    public void OnDrop(PointerEventData eventData)
    {
        // Hücre doluysa bırakma
        if (currentBlock != null) return;

        // Sürüklenen objeden blok bilgisini al
        DraggableBlockUI draggedUI = eventData.pointerDrag?.GetComponent<DraggableBlockUI>();
        if (draggedUI == null) return;

        // Bu sütunun en alt boş hücresini bul
        GridCell targetCell = GridManager.Instance.GetLowestEmptyCellInColumn(gridPosition.x);
        if (targetCell == null || targetCell.currentBlock != null) return;

        // Blok oluşturma
        Block newBlock = SpawnBlock(draggedUI.blockType, targetCell);

        // Blok düşüş animasyonunu başlat
        StartCoroutine(FallToCell(newBlock.transform, targetCell.transform.position, 0.3f));

        // Hedef hücrenin blok referansını güncelle
        targetCell.currentBlock = newBlock;
    }

    /// <summary>
    /// Belirtilen tipe göre yeni blok oluşturur.
    /// </summary>
    private Block SpawnBlock(BlockType blockType, GridCell targetCell)
    {
        Vector3 spawnPos = targetCell.transform.position + Vector3.up * 5f;
        GameObject blockGO = Instantiate(GameManager.Instance.blockPrefab, spawnPos, Quaternion.identity);
        
        Block block = blockGO.GetComponent<Block>();
        block.blockType = blockType;
        return block;
    }

    /// <summary>
    /// Blok'u belirli sürede hedef hücreye düşürür.
    /// </summary>
    private IEnumerator FallToCell(Transform blockTransform, Vector3 targetPosition, float duration)
    {
        Vector3 start = blockTransform.position;
        float time = 0f;

        while (time < duration)
        {
            blockTransform.position = Vector3.Lerp(start, targetPosition, time / duration);
            time += Time.deltaTime;
            yield return null;
        }

        blockTransform.position = targetPosition;
    }
}