using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Grid üzerindeki blokları kontrol eder ve eşleşenleri toplu olarak yok eder.
/// </summary>
public class MatchChecker : MonoBehaviour
{
    [Header("Ses Ayarları")]
    [SerializeField] private AudioClip matchSound;         // Eşleşme sesi
    [SerializeField] private AudioSource audioSource;      // Ses çalacak kaynak

    /// <summary>
    /// Dışarıdan tetiklenir. Coroutine ile eşleşmeleri işler.
    /// </summary>
    public void CheckMatches(GridCell[,] gridCells, int width, int height)
    {
        StartCoroutine(CheckAndDestroyRoutine(gridCells, width, height));
    }

    /// <summary>
    /// Eşleşmeleri bulur, animasyonları oynatır, blokları siler ve zincirleme eşleşmeyi kontrol eder.
    /// </summary>
    private IEnumerator CheckAndDestroyRoutine(GridCell[,] gridCells, int width, int height)
    {
        var matchedBlocks = GetMatchedBlocks(gridCells, width, height);

        if (matchedBlocks.Count == 0)
            yield break;

        Debug.Log($"Eşleşen blok sayısı: {matchedBlocks.Count}");

        // Ses efekti çal
        PlayMatchSound();

        // Skoru güncelleme ve hücre referanslarını temizleme
        foreach (var block in matchedBlocks)
        {
            GameManager.Instance.AddScore(block.blockType.scoreValue);
            ClearBlockReference(gridCells, block);
        }

        // Eş zamanlı animasyon başlat
        foreach (var block in matchedBlocks)
        {
            block.StartCoroutine(block.PlayMatchSequence());
        }

        yield return new WaitForSeconds(0.5f); // Animasyon süresi

        //  Blokları sil
        foreach (var block in matchedBlocks)
        {
            if (block != null)
                Destroy(block.gameObject);
        }

        // Blokları düşür ve zincir eşleşmeleri kontrol et
        yield return new WaitForSeconds(0.2f);
        GridManager.Instance.DropBlocks();

        yield return new WaitForSeconds(0.2f);
        CheckMatches(gridCells, width, height);
    }

    /// <summary>
    /// Grid'deki yatay ve dikey eşleşmeleri bulur.
    /// </summary>
    private HashSet<Block> GetMatchedBlocks(GridCell[,] gridCells, int width, int height)
    {
        HashSet<Block> matched = new HashSet<Block>();

        // Yatay tarama
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width - 2; x++)
            {
                TryAddMatch(gridCells[x, y].currentBlock,
                            gridCells[x + 1, y].currentBlock,
                            gridCells[x + 2, y].currentBlock,
                            matched);
            }
        }

        // Dikey tarama
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height - 2; y++)
            {
                TryAddMatch(gridCells[x, y].currentBlock,
                            gridCells[x, y + 1].currentBlock,
                            gridCells[x, y + 2].currentBlock,
                            matched);
            }
        }

        return matched;
    }

    /// <summary>
    /// Üç blok eşleşiyorsa, eşleşme listesine eklenir.
    /// </summary>
    private void TryAddMatch(Block b1, Block b2, Block b3, HashSet<Block> matched)
    {
        if (b1 == null || b2 == null || b3 == null) return;

        if (b1.blockType == b2.blockType && b2.blockType == b3.blockType)
        {
            matched.Add(b1);
            matched.Add(b2);
            matched.Add(b3);
        }
    }

    /// <summary>
    /// Blok silinmeden önce hücre referansını temizler.
    /// </summary>
    private void ClearBlockReference(GridCell[,] gridCells, Block block)
    {
        foreach (var cell in gridCells)
        {
            if (cell.currentBlock == block)
            {
                cell.currentBlock = null;
                return;
            }
        }
    }

    /// <summary>
    /// Eşleşme sesini çalar.
    /// </summary>
    private void PlayMatchSound()
    {
        if (audioSource != null && matchSound != null)
        {
            audioSource.PlayOneShot(matchSound);
        }
    }
}