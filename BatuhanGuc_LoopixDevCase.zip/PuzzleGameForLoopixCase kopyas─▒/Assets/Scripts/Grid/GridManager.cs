using UnityEngine;

/// <summary>
/// GridManager: Oyundaki grid yapısını oluşturur, blok yerleşimlerini ve kontrolleri yönetir.
/// </summary>
public class GridManager : MonoBehaviour
{
    public static GridManager Instance { get; private set; }

    [Header("Grid Ayarları")]
    [SerializeField] private int gridWidth = 4;
    [SerializeField] private int gridHeight = 4;
    [SerializeField] private float spacing = 1.1f;

    [Header("Prefablar ve Bileşenler")]
    [SerializeField] private GameObject gridCellPrefab;
    [SerializeField] private GameObject blockPrefab;
    [SerializeField] private MatchChecker matchChecker;

    private GridCell[,] gridCells;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        GenerateGrid();
        FocusCameraOnGrid();
    }

    /// <summary>
    /// Grid hücrelerini sahneye oluşturur.
    /// </summary>
    private void GenerateGrid()
    {
        gridCells = new GridCell[gridWidth, gridHeight];

        Vector2 startPos = new Vector2(
            -(gridWidth - 1) * 0.5f * spacing,
            -(gridHeight - 1) * 0.5f * spacing
        );

        for (int x = 0; x < gridWidth; x++)
        {
            for (int y = 0; y < gridHeight; y++)
            {
                Vector2 cellPos = new Vector2(x * spacing, y * spacing) + startPos;

                GameObject cellGO = Instantiate(gridCellPrefab, cellPos, Quaternion.identity, transform);
                cellGO.name = $"Cell_{x}_{y}";

                GridCell cell = cellGO.GetComponent<GridCell>() ?? cellGO.AddComponent<GridCell>();
                cell.gridPosition = new Vector2Int(x, y);
                cell.currentBlock = null;

                gridCells[x, y] = cell;
            }
        }
    }

    /// <summary>
    /// Kamerayı grid'in merkezine hizalar.
    /// </summary>
    private void FocusCameraOnGrid()
    {
        if (Camera.main != null)
        {
            Camera.main.transform.position = new Vector3(0, -0.8f, -10);
        }
    }

    /// <summary>
    /// Verilen sütundaki en alt boş hücreyi döndürür.
    /// </summary>
    public GridCell GetLowestEmptyCellInColumn(int columnX)
    {
        for (int y = 0; y < gridHeight; y++)
        {
            if (gridCells[columnX, y].currentBlock == null)
                return gridCells[columnX, y];
        }

        return null;
    }

    /// <summary>
    /// Dünya pozisyonuna en yakın sütundaki en alt boş hücreyi döndürür.
    /// </summary>
    public GridCell GetLowestEmptyCellInColumnByWorldPos(Vector3 worldPos)
    {
        float minDist = float.MaxValue;
        int closestColumn = 0;

        for (int x = 0; x < gridWidth; x++)
        {
            float dist = Mathf.Abs(gridCells[x, 0].transform.position.x - worldPos.x);
            if (dist < minDist)
            {
                minDist = dist;
                closestColumn = x;
            }
        }

        return GetLowestEmptyCellInColumn(closestColumn);
    }

    /// <summary>
    /// Belirli hücrenin dünya pozisyonunu verir.
    /// </summary>
    public Vector3 GetCellWorldPosition(int x, int y)
    {
        return gridCells[x, y].transform.position;
    }

    /// <summary>
    /// Eşleşmeleri kontrol ettirir.
    /// Grid doluysa Game Over'ı tetikler.
    /// </summary>
    public void CheckForMatches()
    {
        matchChecker.CheckMatches(gridCells, gridWidth, gridHeight);

        if (IsGridFull())
        {
            UIManager.Instance.ShowGameOver();
        }
    }

    /// <summary>
    /// Grid üzerindeki boşlukları yukarıdaki bloklarla doldurur.
    /// </summary>
    public void DropBlocks()
    {
        for (int x = 0; x < gridWidth; x++)
        {
            for (int y = 0; y < gridHeight - 1; y++)
            {
                if (gridCells[x, y].currentBlock == null)
                {
                    for (int k = y + 1; k < gridHeight; k++)
                    {
                        if (gridCells[x, k].currentBlock != null)
                        {
                            Block blockToDrop = gridCells[x, k].currentBlock;

                            gridCells[x, y].currentBlock = blockToDrop;
                            gridCells[x, k].currentBlock = null;

                            StartCoroutine(blockToDrop.FallAndPlace(gridCells[x, y]));
                            break;
                        }
                    }
                }
            }
        }
    }

    /// <summary>
    /// Grid tamamen dolu mu kontrol eder.
    /// </summary>
    private bool IsGridFull()
    {
        for (int x = 0; x < gridWidth; x++)
        {
            for (int y = 0; y < gridHeight; y++)
            {
                if (gridCells[x, y].currentBlock == null)
                    return false;
            }
        }
        return true;
    }

    /// <summary>
    /// Blok prefab'ına dış erişim (sadece okunabilir).
    /// </summary>
    public GameObject BlockPrefab => blockPrefab;
}