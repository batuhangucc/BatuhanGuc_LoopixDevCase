using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// UI üzerinden blok sürükleyip sahneye bırakmayı yönetir.
/// </summary>
public class DraggableBlockUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [Header("Blok Ayarları")]
    public BlockType blockType;                    // Sürüklenen blok tipi
    public BlockUIManager manager;                 // UI üzerindeki blok sayacını yöneten referans

    [Header("Ses")]
    [SerializeField] private AudioClip placeSound; // Yerleştirme sesi

    private GameObject preview;                    // Sürükleme sırasında görünen önizleme
    private RectTransform rectTransform;           // Bu UI nesnesinin RectTransform'u
    private Canvas canvas;                         // Bağlı olduğu canvas

    private void Start()
    {
        rectTransform = GetComponent<RectTransform>();
        canvas = GetComponentInParent<Canvas>();
    }

    /// <summary>
    /// Sürükleme başladığında çalışır.
    /// </summary>
    public void OnBeginDrag(PointerEventData eventData)
    {
        preview = CreatePreview();                                 // UI'de görsel önizleme oluştur
        UIManager.Instance.selectedBlockType = blockType;          // Seçilen blok türünü UIManager'a bildir
    }

    /// <summary>
    /// Sürükleme sırasında çalışır.
    /// </summary>
    public void OnDrag(PointerEventData eventData)
    {
        if (preview == null) return;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            canvas.transform as RectTransform,
            eventData.position,
            eventData.pressEventCamera,
            out Vector2 localPoint))
        {
            preview.GetComponent<RectTransform>().localPosition = localPoint;
        }
    }

    /// <summary>
    /// Sürükleme bırakıldığında çalışır.
    /// </summary>
    public void OnEndDrag(PointerEventData eventData)
    {
        Vector3 worldPos = Camera.main.ScreenToWorldPoint(eventData.position);
        worldPos.z = 0;

        // Pozisyona en yakın boş hücre bulunur
        GridCell cell = GridManager.Instance.GetLowestEmptyCellInColumnByWorldPos(worldPos);

        if (cell != null && cell.currentBlock == null)
        {
            // Yeni blok instantiate edilir
            GameObject go = Instantiate(GameManager.Instance.blockPrefab, cell.transform.position + Vector3.up * 3f, Quaternion.identity);
            Block block = go.GetComponent<Block>();
            block.blockType = blockType;
            block.ApplyVisuals();

            if (placeSound != null)
                AudioSource.PlayClipAtPoint(placeSound, Camera.main.transform.position);

            // Arka plan efekti tetiklenir
            BackgroundColorController.Instance.TriggerPulse(block.transform.position, block.blockType.color);

            // Blok sahneye düşürülür
            StartCoroutine(block.FallAndPlace(cell));

            // UI'deki blok sayacı güncellenir
            manager?.OnBlockPlaced();
        }

        Destroy(preview);                                        // Önizleme silinir
        UIManager.Instance.selectedBlockType = null;             // Seçim sıfırlanır
    }

    /// <summary>
    /// Sürükleme önizleme görselini oluşturur.
    /// </summary>
    private GameObject CreatePreview()
    {
        GameObject go = new GameObject("DragPreview", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(canvas.transform);
        go.transform.SetAsLastSibling(); // Her şeyin üstünde görünmesi için

        Image img = go.GetComponent<Image>();
        Image original = GetComponent<Image>();

        img.sprite = original.sprite;
        img.color = original.color;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = rectTransform.sizeDelta * 0.5f; // Küçültmek için
        rt.pivot = rectTransform.pivot;

        return go;
    }
}