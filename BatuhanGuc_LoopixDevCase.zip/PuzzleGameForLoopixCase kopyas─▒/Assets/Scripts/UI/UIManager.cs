using UnityEngine;
using TMPro;
using System.Collections;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("Seçilen Blok Türü")]
    public BlockType selectedBlockType;

    [Header("UI Elemanları")]
    [SerializeField] private GameObject gameOverText;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    /// <summary>
    /// Blok türü seçimlerini yönetir.
    /// </summary>
    public void SelectBlockType(BlockType type)
    {
        selectedBlockType = type;
        Debug.Log("Blok seçildi: " + type.name);
    }

    /// <summary>
    /// Skor yazısına animasyon uygular.
    /// </summary>
    public void AnimateScoreText(TextMeshProUGUI text)
    {
        if (text == null) return;
        StartCoroutine(AnimateTextScale(text));
    }

    private IEnumerator AnimateTextScale(TextMeshProUGUI text)
    {
        float duration = 0.1f;
        float t = 0f;
        Vector3 originalScale = text.transform.localScale;
        Vector3 targetScale = originalScale * 1.2f;

        // Büyüt
        while (t < duration)
        {
            t += Time.deltaTime;
            float progress = t / duration;
            text.transform.localScale = Vector3.Lerp(originalScale, targetScale, progress);
            yield return null;
        }

        // Küçült
        t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            float progress = t / duration;
            text.transform.localScale = Vector3.Lerp(targetScale, originalScale, progress);
            yield return null;
        }

        text.transform.localScale = originalScale;
    }

    /// <summary>
    /// Game Over ekranını gösterir.
    /// </summary>
    public void ShowGameOver()
    {
        if (gameOverText != null)
        {
            gameOverText.SetActive(true);
        }
        else
        {
            Debug.LogWarning("GameOver UI öğesi atanmadı!");
        }
    }
}