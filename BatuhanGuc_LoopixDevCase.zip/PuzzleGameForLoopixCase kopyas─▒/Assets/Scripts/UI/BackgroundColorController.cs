using UnityEngine;
using System.Collections;

public class BackgroundColorController : MonoBehaviour
{
    public static BackgroundColorController Instance { get; private set; }

    [SerializeField] private Material backgroundMaterial;

    [Header("Shader Property Names")]
    [SerializeField] private string pulseCenterProperty = "_PulseCenter";
    [SerializeField] private string pulseRadiusProperty = "_PulseRadius";
    [SerializeField] private string pulseStrengthProperty = "_PulseStrength";
    [SerializeField] private string pulseColorProperty = "_PulseColor";

    [Header("Pulse Ayarları")]
    [SerializeField] private float growDuration = 0.4f;
    [SerializeField] private float fadeDuration = 0.5f;
    [SerializeField] private float maxRadius = 1.5f;
    [SerializeField] private float maxStrength = 1.2f;

    private Coroutine pulseCoroutine;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void TriggerPulse(Vector3 worldPosition, Color color)
    {
        Vector3 viewportPos = Camera.main.WorldToViewportPoint(worldPosition);
        Vector2 uv = new Vector2(viewportPos.x, viewportPos.y);

        if (pulseCoroutine != null)
            StopCoroutine(pulseCoroutine);

        pulseCoroutine = StartCoroutine(PulseRoutine(uv, color));
    }

   private IEnumerator PulseRoutine(Vector2 uv, Color pulseColor)
{
    backgroundMaterial.SetVector(pulseCenterProperty, uv);
    backgroundMaterial.SetColor(pulseColorProperty, pulseColor);

    float radius = 0f;
    float strength = 0f;

    // 1. Büyüme
    float t = 0f;
    while (t < growDuration)
    {
        float normalized = t / growDuration;
        radius = Mathf.Lerp(0f, maxRadius, normalized);
        strength = Mathf.Lerp(0f, maxStrength, normalized);

        backgroundMaterial.SetFloat(pulseRadiusProperty, radius);
        backgroundMaterial.SetFloat(pulseStrengthProperty, strength);

        t += Time.deltaTime;
        yield return null;
    }

    //  2. Geri Sönme
    t = 0f;
    while (t < fadeDuration)
    {
        float normalized = t / fadeDuration;
        radius = Mathf.Lerp(maxRadius, 0f, normalized);
        strength = Mathf.Lerp(maxStrength, 0f, normalized);

        backgroundMaterial.SetFloat(pulseRadiusProperty, radius);
        backgroundMaterial.SetFloat(pulseStrengthProperty, strength);

        t += Time.deltaTime;
        yield return null;
    }

    //3. Tam resetle
    backgroundMaterial.SetFloat(pulseRadiusProperty, 0f);
    backgroundMaterial.SetFloat(pulseStrengthProperty, 0f);
    backgroundMaterial.SetColor(pulseColorProperty, Color.black); 
}
}