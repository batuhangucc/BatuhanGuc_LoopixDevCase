using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// UI'da sürüklenebilir bloğun ve sıradaki bloğun görsel yönetimini sağlar.
/// </summary>
public class BlockUIManager : MonoBehaviour
{
    [Header("Blok Türleri")]
    [Tooltip("Oyunda kullanılabilecek tüm blok tipleri.")]
    public BlockType[] blockTypes;

    [Header("UI Referansları")]
    [Tooltip("Sol blok (kullanıcı tarafından sürüklenebilir olan).")]
    public DraggableBlockUI draggableBlock;

    [Tooltip("Sağ blok (bir sonraki gelecek olan).")]
    public Image nextBlockImage;

    private BlockType currentType;
    private BlockType nextType;

    private void Start()
    {
        currentType = GetRandomBlock();
        nextType = GetRandomBlock();

        UpdateUI(initial: true);
    }

    /// <summary>
    /// Blok sahneye yerleştirildiğinde çağrılır, UI güncellenir.
    /// </summary>
    public void OnBlockPlaced()
    {
        currentType = nextType;
        nextType = GetRandomBlock();

        UpdateUI();
    }

    /// <summary>
    /// UI’daki sürüklenebilir ve sıradaki blokları günceller.
    /// </summary>
    private void UpdateUI(bool initial = false)
    {
        // Sol (draggable) blok görselini güncelle
        draggableBlock.blockType = currentType;

        Image dragImage = draggableBlock.GetComponent<Image>();
        dragImage.sprite = currentType.sprite;
        dragImage.color = currentType.color;

        // Sağ (next) blok animasyonla geçiş yapsın
        if (initial)
        {
            nextBlockImage.sprite = nextType.sprite;
            nextBlockImage.color = nextType.color;
        }
        else
        {
            StartCoroutine(AnimateSwap(nextBlockImage, nextType));
        }
    }

    /// <summary>
    /// Sıradaki bloğun yumuşak geçişle güncellenmesini sağlar.
    /// </summary>
    private IEnumerator AnimateSwap(Image image, BlockType newType)
    {
        float duration = 0.15f;
        Vector3 originalScale = image.rectTransform.localScale;
        Color originalColor = image.color;

        // Kaybolma animasyonu
        for (float t = 0; t < duration; t += Time.deltaTime)
        {
            float n = t / duration;
            image.rectTransform.localScale = Vector3.Lerp(originalScale, Vector3.zero, n);
            image.color = Color.Lerp(originalColor, new Color(originalColor.r, originalColor.g, originalColor.b, 0f), n);
            yield return null;
        }

        // Yeni sprite ve renk ata
        image.sprite = newType.sprite;
        image.color = new Color(newType.color.r, newType.color.g, newType.color.b, 0f);

        // Geri gelme animasyonu
        for (float t = 0; t < duration; t += Time.deltaTime)
        {
            float n = t / duration;
            image.rectTransform.localScale = Vector3.Lerp(Vector3.zero, originalScale, n);
            image.color = Color.Lerp(image.color, newType.color, n);
            yield return null;
        }

        // Final değerleri sabitle
        image.rectTransform.localScale = originalScale;
        image.color = newType.color;
    }

    /// <summary>
    /// Rastgele bir BlockType döner.
    /// </summary>
    private BlockType GetRandomBlock()
    {
        return blockTypes[Random.Range(0, blockTypes.Length)];
    }
}