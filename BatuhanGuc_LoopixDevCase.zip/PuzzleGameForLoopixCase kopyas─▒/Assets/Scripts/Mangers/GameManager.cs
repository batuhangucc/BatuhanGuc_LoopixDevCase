using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Prefablar")]
    public GameObject blockPrefab;

    [Header("Skor")]
    public TextMeshProUGUI text;
    public int score { get; private set; }

    [Header("Ses Kontrolü")]
    public bool isSoundOn = true; // Ses açık mı?

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
        DontDestroyOnLoad(blockPrefab);
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Sahne yeniden yüklendiğinde scoreText'ini yeniden bul
        if (text == null)
        {
            text = GameObject.FindWithTag("ScoreText")?.GetComponent<TextMeshProUGUI>();
        }
    }

    /// <summary>
    /// Skor ekler ve UI'yı günceller.
    /// </summary>
    public void AddScore(int value)
    {
        score += value;
        Debug.Log("Score: " + score);

        if (text != null)
        {
            text.text = "Score " + score.ToString();
            UIManager.Instance.AnimateScoreText(text);
        }
    }

    /// <summary>
    /// Oyunu yeniden başlatır.
    /// </summary>
    public void ResetGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    /// <summary>
    /// UI butonuyla ses toggle.
    /// </summary>
    public void ToggleSound()
{
    isSoundOn = !isSoundOn;
    AudioListener.volume = isSoundOn ? 1f : 0f;

    Debug.Log("Ses durumu: " + (isSoundOn ? "Açık" : "Kapalı"));
}
}