using UnityEngine;

[CreateAssetMenu(fileName = "BlockType", menuName = "Match3/Block Type")]

public class BlockType : ScriptableObject
{
    public string typeName;
    public Sprite sprite;
    public Color color;
    public int scoreValue;
    public Material material;
    
 }
    

